const express = require("express");
const bodyParser = require("body-parser");
const db = require("./firebase"); // Configuración de Firebase
const setupSwaggerDocs = require("./swagger"); // Swagger

const app = express();
app.use(bodyParser.json());

// Configurar Swagger
setupSwaggerDocs(app);

// Ruta raíz
app.get("/", (req, res) => {
    res.send("Bienvenido a la API de la rentadora de máquinas");
});

// **Swagger Documentation para las Entidades**
/**
 * @swagger
 * components:
 *   schemas:
 *     Usuario:
 *       type: object
 *       properties:
 *         nombre:
 *           type: string
 *         correo:
 *           type: string
 *         rol:
 *           type: string
 *         fechaRegistro:
 *           type: string
 *           format: date-time
 *
 *     Maquina:
 *       type: object
 *       properties:
 *         nombre:
 *           type: string
 *         descripcion:
 *           type: string
 *         precio:
 *           type: number
 *           format: float
 *         distribuidor:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *             nombre:
 *               type: string
 *
 *     Alquiler:
 *       type: object
 *       properties:
 *         usuario:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *         maquina:
 *           type: object
 *           properties:
 *             id:
 *               type: string
 *         fecha_inicio:
 *           type: string
 *           format: date-time
 *         fecha_fin:
 *           type: string
 *           format: date-time
 *         estado:
 *           type: string
 *
 *     Pago:
 *       type: object
 *       properties:
 *         alquiler_id:
 *           type: string
 *         monto:
 *           type: number
 *           format: float
 *         fecha_pago:
 *           type: string
 *           format: date-time
 *         metodo_pago:
 *           type: string
 *
 *     Distribuidor:
 *       type: object
 *       properties:
 *         nombre:
 *           type: string
 *         correo:
 *           type: string
 *         telefono:
 *           type: string
 *         direccion:
 *           type: string
 */

// **CRUD para Usuarios**

/**
 * @swagger
 * /usuarios:
 *   post:
 *     summary: Crear un nuevo usuario
 *     tags: [Usuarios]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Usuario'
 *     responses:
 *       201:
 *         description: Usuario creado con éxito
 */
app.post("/usuarios", async (req, res) => {
    try {
        const { nombre, correo, rol } = req.body;
        if (!nombre || !correo || !rol) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios: nombre, correo y rol." });
        }

        const nuevoUsuario = { nombre, correo, rol, fechaRegistro: new Date().toISOString() };
        const docRef = await db.collection("usuarios").add(nuevoUsuario);
        res.status(201).json({ id: docRef.id, ...nuevoUsuario });
    } catch (error) {
        console.error("Error al crear usuario:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /usuarios/{id}:
 *   get:
 *     summary: Obtener un usuario por ID
 *     tags: [Usuarios]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del usuario
 *     responses:
 *       200:
 *         description: Usuario encontrado
 *       404:
 *         description: Usuario no encontrado
 */
app.get("/usuarios/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const doc = await db.collection("usuarios").doc(id).get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Usuario no encontrado." });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
    } catch (error) {
        console.error("Error al obtener usuario:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /usuarios/{id}:
 *   put:
 *     summary: Actualizar un usuario por ID
 *     tags: [Usuarios]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del usuario
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Usuario'
 *     responses:
 *       200:
 *         description: Usuario actualizado con éxito
 *       404:
 *         description: Usuario no encontrado
 */
app.put("/usuarios/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, correo, rol } = req.body;
        const usuarioRef = db.collection("usuarios").doc(id);

        const doc = await usuarioRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Usuario no encontrado." });
        }

        await usuarioRef.update({ nombre, correo, rol });
        res.status(200).json({ mensaje: "Usuario actualizado con éxito" });
    } catch (error) {
        console.error("Error al actualizar usuario:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /usuarios/{id}:
 *   delete:
 *     summary: Eliminar un usuario por ID
 *     tags: [Usuarios]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del usuario
 *     responses:
 *       200:
 *         description: Usuario eliminado con éxito
 *       404:
 *         description: Usuario no encontrado
 */
app.delete("/usuarios/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const usuarioRef = db.collection("usuarios").doc(id);

        const doc = await usuarioRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Usuario no encontrado." });
        }

        await usuarioRef.delete();
        res.status(200).json({ mensaje: "Usuario eliminado con éxito" });
    } catch (error) {
        console.error("Error al eliminar usuario:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

// **CRUD para Máquinas**

/**
 * @swagger
 * /maquinas:
 *   post:
 *     summary: Crear una nueva máquina
 *     tags: [Máquinas]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Maquina'
 *     responses:
 *       201:
 *         description: Máquina creada con éxito
 */
app.post("/maquinas", async (req, res) => {
    try {
        const { nombre, descripcion, precio, distribuidor } = req.body;
        if (!nombre || !descripcion || !precio || !distribuidor) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios: nombre, descripción, precio y distribuidor." });
        }

        const nuevaMaquina = { nombre, descripcion, precio, distribuidor };
        const docRef = await db.collection("maquinas").add(nuevaMaquina);
        res.status(201).json({ id: docRef.id, ...nuevaMaquina });
    } catch (error) {
        console.error("Error al crear máquina:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /maquinas/{id}:
 *   get:
 *     summary: Obtener una máquina por ID
 *     tags: [Máquinas]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID de la máquina
 *     responses:
 *       200:
 *         description: Máquina encontrada
 *       404:
 *         description: Máquina no encontrada
 */
app.get("/maquinas/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const doc = await db.collection("maquinas").doc(id).get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Máquina no encontrada." });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
    } catch (error) {
        console.error("Error al obtener máquina:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /maquinas/{id}:
 *   put:
 *     summary: Actualizar una máquina por ID
 *     tags: [Máquinas]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID de la máquina
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Maquina'
 *     responses:
 *       200:
 *         description: Máquina actualizada con éxito
 *       404:
 *         description: Máquina no encontrada
 */
app.put("/maquinas/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, descripcion, precio, distribuidor } = req.body;
        const maquinaRef = db.collection("maquinas").doc(id);

        const doc = await maquinaRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Máquina no encontrada." });
        }

        await maquinaRef.update({ nombre, descripcion, precio, distribuidor });
        res.status(200).json({ mensaje: "Máquina actualizada con éxito" });
    } catch (error) {
        console.error("Error al actualizar máquina:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /maquinas/{id}:
 *   delete:
 *     summary: Eliminar una máquina por ID
 *     tags: [Máquinas]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID de la máquina
 *     responses:
 *       200:
 *         description: Máquina eliminada con éxito
 *       404:
 *         description: Máquina no encontrada
 */
app.delete("/maquinas/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const maquinaRef = db.collection("maquinas").doc(id);

        const doc = await maquinaRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Máquina no encontrada." });
        }

        await maquinaRef.delete();
        res.status(200).json({ mensaje: "Máquina eliminada con éxito" });
    } catch (error) {
        console.error("Error al eliminar máquina:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

// **CRUD para Alquileres, Pagos, y Distribuidores (similar a lo anterior)**
// **CRUD para Alquileres**

/**
 * @swagger
 * /alquileres:
 *   post:
 *     summary: Crear un nuevo alquiler
 *     tags: [Alquileres]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Alquiler'
 *     responses:
 *       201:
 *         description: Alquiler creado con éxito
 */
app.post("/alquileres", async (req, res) => {
    try {
        const { usuario, maquina, fecha_inicio, fecha_fin, estado } = req.body;

        if (!usuario || !maquina || !fecha_inicio || !fecha_fin || !estado) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios: usuario, máquina, fecha_inicio, fecha_fin, estado." });
        }

        const nuevoAlquiler = { usuario, maquina, fecha_inicio, fecha_fin, estado };
        const docRef = await db.collection("alquileres").add(nuevoAlquiler);
        res.status(201).json({ id: docRef.id, ...nuevoAlquiler });
    } catch (error) {
        console.error("Error al crear alquiler:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /alquileres/{id}:
 *   get:
 *     summary: Obtener un alquiler por ID
 *     tags: [Alquileres]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del alquiler
 *     responses:
 *       200:
 *         description: Alquiler encontrado
 *       404:
 *         description: Alquiler no encontrado
 */
app.get("/alquileres/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const doc = await db.collection("alquileres").doc(id).get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Alquiler no encontrado." });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
    } catch (error) {
        console.error("Error al obtener alquiler:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /alquileres/{id}:
 *   put:
 *     summary: Actualizar un alquiler por ID
 *     tags: [Alquileres]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del alquiler
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Alquiler'
 *     responses:
 *       200:
 *         description: Alquiler actualizado con éxito
 *       404:
 *         description: Alquiler no encontrado
 */
app.put("/alquileres/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { usuario, maquina, fecha_inicio, fecha_fin, estado } = req.body;
        const alquilerRef = db.collection("alquileres").doc(id);

        const doc = await alquilerRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Alquiler no encontrado." });
        }

        await alquilerRef.update({ usuario, maquina, fecha_inicio, fecha_fin, estado });
        res.status(200).json({ mensaje: "Alquiler actualizado con éxito" });
    } catch (error) {
        console.error("Error al actualizar alquiler:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /alquileres/{id}:
 *   delete:
 *     summary: Eliminar un alquiler por ID
 *     tags: [Alquileres]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del alquiler
 *     responses:
 *       200:
 *         description: Alquiler eliminado con éxito
 *       404:
 *         description: Alquiler no encontrado
 */
app.delete("/alquileres/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const alquilerRef = db.collection("alquileres").doc(id);

        const doc = await alquilerRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Alquiler no encontrado." });
        }

        await alquilerRef.delete();
        res.status(200).json({ mensaje: "Alquiler eliminado con éxito" });
    } catch (error) {
        console.error("Error al eliminar alquiler:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

// **CRUD para Pagos**

/**
 * @swagger
 * /pagos:
 *   post:
 *     summary: Crear un nuevo pago
 *     tags: [Pagos]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Pago'
 *     responses:
 *       201:
 *         description: Pago realizado con éxito
 */
app.post("/pagos", async (req, res) => {
    try {
        const { alquilerId, monto, metodo, fecha_pago } = req.body;

        if (!alquilerId || !monto || !metodo || !fecha_pago) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios: alquilerId, monto, metodo, fecha_pago." });
        }

        const nuevoPago = { alquilerId, monto, metodo, fecha_pago };
        const docRef = await db.collection("pagos").add(nuevoPago);
        res.status(201).json({ id: docRef.id, ...nuevoPago });
    } catch (error) {
        console.error("Error al crear pago:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /pagos/{id}:
 *   get:
 *     summary: Obtener un pago por ID
 *     tags: [Pagos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del pago
 *     responses:
 *       200:
 *         description: Pago encontrado
 *       404:
 *         description: Pago no encontrado
 */
app.get("/pagos/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const doc = await db.collection("pagos").doc(id).get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Pago no encontrado." });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
    } catch (error) {
        console.error("Error al obtener pago:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /pagos/{id}:
 *   put:
 *     summary: Actualizar un pago por ID
 *     tags: [Pagos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del pago
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Pago'
 *     responses:
 *       200:
 *         description: Pago actualizado con éxito
 *       404:
 *         description: Pago no encontrado
 */
app.put("/pagos/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { alquilerId, monto, metodo, fecha_pago } = req.body;
        const pagoRef = db.collection("pagos").doc(id);

        const doc = await pagoRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Pago no encontrado." });
        }

        await pagoRef.update({ alquilerId, monto, metodo, fecha_pago });
        res.status(200).json({ mensaje: "Pago actualizado con éxito" });
    } catch (error) {
        console.error("Error al actualizar pago:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /pagos/{id}:
 *   delete:
 *     summary: Eliminar un pago por ID
 *     tags: [Pagos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del pago
 *     responses:
 *       200:
 *         description: Pago eliminado con éxito
 *       404:
 *         description: Pago no encontrado
 */
app.delete("/pagos/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const pagoRef = db.collection("pagos").doc(id);

        const doc = await pagoRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Pago no encontrado." });
        }

        await pagoRef.delete();
        res.status(200).json({ mensaje: "Pago eliminado con éxito" });
    } catch (error) {
        console.error("Error al eliminar pago:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

// **CRUD para Distribuidores**

/**
 * @swagger
 * /distribuidores:
 *   post:
 *     summary: Crear un nuevo distribuidor
 *     tags: [Distribuidores]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Distribuidor'
 *     responses:
 *       201:
 *         description: Distribuidor creado con éxito
 */
app.post("/distribuidores", async (req, res) => {
    try {
        const { nombre, correo, telefono, direccion } = req.body;

        if (!nombre || !correo || !telefono || !direccion) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios: nombre, correo, telefono, direccion." });
        }

        const nuevoDistribuidor = { nombre, correo, telefono, direccion };
        const docRef = await db.collection("distribuidores").add(nuevoDistribuidor);
        res.status(201).json({ id: docRef.id, ...nuevoDistribuidor });
    } catch (error) {
        console.error("Error al crear distribuidor:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /distribuidores/{id}:
 *   get:
 *     summary: Obtener un distribuidor por ID
 *     tags: [Distribuidores]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del distribuidor
 *     responses:
 *       200:
 *         description: Distribuidor encontrado
 *       404:
 *         description: Distribuidor no encontrado
 */
app.get("/distribuidores/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const doc = await db.collection("distribuidores").doc(id).get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Distribuidor no encontrado." });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
    } catch (error) {
        console.error("Error al obtener distribuidor:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /distribuidores/{id}:
 *   put:
 *     summary: Actualizar un distribuidor por ID
 *     tags: [Distribuidores]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del distribuidor
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Distribuidor'
 *     responses:
 *       200:
 *         description: Distribuidor actualizado con éxito
 *       404:
 *         description: Distribuidor no encontrado
 */
app.put("/distribuidores/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, correo, telefono, direccion } = req.body;
        const distribuidorRef = db.collection("distribuidores").doc(id);

        const doc = await distribuidorRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Distribuidor no encontrado." });
        }

        await distribuidorRef.update({ nombre, correo, telefono, direccion });
        res.status(200).json({ mensaje: "Distribuidor actualizado con éxito" });
    } catch (error) {
        console.error("Error al actualizar distribuidor:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});

/**
 * @swagger
 * /distribuidores/{id}:
 *   delete:
 *     summary: Eliminar un distribuidor por ID
 *     tags: [Distribuidores]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del distribuidor
 *     responses:
 *       200:
 *         description: Distribuidor eliminado con éxito
 *       404:
 *         description: Distribuidor no encontrado
 */
app.delete("/distribuidores/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const distribuidorRef = db.collection("distribuidores").doc(id);

        const doc = await distribuidorRef.get();

        if (!doc.exists) {
            return res.status(404).json({ mensaje: "Distribuidor no encontrado." });
        }

        await distribuidorRef.delete();
        res.status(200).json({ mensaje: "Distribuidor eliminado con éxito" });
    } catch (error) {
        console.error("Error al eliminar distribuidor:", error);
        res.status(500).json({ mensaje: "Error interno del servidor." });
    }
});



// Define CRUD para Alquileres, Pagos, y Distribuidores de manera similar al de Usuario y Máquina.

app.listen(3000, () => {
    console.log("Servidor corriendo en http://localhost:3000");
});
